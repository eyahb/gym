float imc1(float poids,float taille);
