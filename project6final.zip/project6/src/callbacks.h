#include <gtk/gtk.h>




void
on_bt_gest_don_ad_clicked              (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_bt_inscri_seance_adh_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_bt_gest_rdv_staff_adh_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_bt_retour_adh_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_bt_ajout_donnee_adh_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_bt_modif_donnee_adh_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_bt_supp_donnee_adh_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_bt_valid_adh_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_bt_ajouter_donnee_adh_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_bt_retour2_adh_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_bt_valid1_adh_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_bt_ajouter1_rdv_adh_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_bt_retour_staff_adh_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_bt_retour_rdv_adh_clicked           (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_bt_valid2_adh_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_bt_retour_event_adh_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_bt_retour1_adh_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_bt_retour3_adh_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_bt_retour4_adh_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_bt_logout_espace_adh_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_bt_login_adh_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_bt_quitter_adh_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_bt_inscrip_seance_adh_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_calcul_IMC_adh_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_bt_retour5_adh_clicked              (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_bt_modif1_adh_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_bt_modif2_seance_adh_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_bt_supp2_seance_adh_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_bt_profil_adh_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_bt_supp_rdv_adh_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_bt_retour_profil_adh_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
